package com.springhibernate.juintTest;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.OngoingStubbing;

import com.springhibernate.DAO.EmployeeProjectDAO;
import com.springhibernate.entity.Employee;
import com.springhibernate.entity.Project;
import com.springhibernate.service.EmployeeProjectService;
import com.springhibernate.service.EmployeeProjectServiceImpl;

import junit.framework.Assert;

@RunWith(MockitoJUnitRunner.class)
public class TestService {
	
	@Mock
	private EmployeeProjectDAO employeeProjectDAO;
	
	@InjectMocks
	private EmployeeProjectService employeeProjectService = new EmployeeProjectServiceImpl();
	
	
	private List<Employee> employee = new ArrayList();
	private List<Project> project = new ArrayList();

	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		
		Employee emp1 = new Employee();
		emp1.setEmployeeName("Chaitra");
		emp1.setStartDate("12/12/2020");
		emp1.setEndDate("12/12/2020");
		emp1.setProjectName("SAP");
		emp1.setSubTask("Developer");
		emp1.setEmployeeListSelected(null);
		emp1.setId(0);
		emp1.setProject(null);
		emp1.setProject_id(0);
		employee.add(emp1);
		
		Employee emp2 = new Employee();
		emp2.setEmployeeName("Swathi");
		emp2.setStartDate("12/12/2020");
		emp2.setEndDate("12/12/2020");
		emp2.setProjectName("Mindtree");
		emp2.setSubTask("Developer");
		emp2.setEmployeeListSelected(null);
		emp2.setId(0);
		emp2.setProject(null);
		emp2.setProject_id(0);
		employee.add(emp2);
		
		
		Project prj1 = new Project();
		prj1.setId(0);
		prj1.setProjectName("SAP");
		prj1.setProjectsAvailable(null);
		project.add(prj1);
		
		Project prj2 = new Project();
		prj1.setId(1);
		prj1.setProjectName("Mindtree");
		prj1.setProjectsAvailable(null);
		project.add(prj2);
	
	}
	
	@Test
	public void getEmployeeListTest1() throws Exception{
		Mockito.when(employeeProjectDAO.getEmployeeList(Mockito.any(String.class))).thenReturn(employee);
		List<Employee> emp = employeeProjectService.getEmployeeList("prj2");
		Assert.assertEquals(emp, employee);	
	}
	
	@Test
	public void getEmployeeListTest2() throws Exception{
		Mockito.when(employeeProjectDAO.getEmployeeList(Mockito.any(String.class))).thenReturn(employee);
		List<Employee> emp = employeeProjectService.getEmployeeList("prj2");
		Assert.assertNotNull(emp);	
	}
	
	@Test
	public void getEmployeeListTest3() throws Exception{
		Mockito.when(employeeProjectDAO.getEmployeeList(Mockito.any(String.class))).thenReturn(employee);
		List<Employee> emp = employeeProjectService.getEmployeeList("prj2");
		Assert.assertNotSame(emp, null);
	}
	
	
	@Test
	public void getProjectNamesJSONTest1() throws Exception{
		Mockito.when(employeeProjectDAO.getProjectNamesJSON()).thenReturn(project);
		List<Project> prj = employeeProjectService.getProjectNamesJSON();
		Assert.assertEquals(project, prj);	
	}
	
	@Test
	public void getProjectNamesJSONTest2() throws Exception{
		Mockito.when(employeeProjectDAO.getProjectNamesJSON()).thenReturn(project);
		List<Project> prj = employeeProjectService.getProjectNamesJSON();
		Assert.assertNotNull(prj);
	}
	
	@Test
	public void getProjectNamesJSONTest3() throws Exception{
		Mockito.when(employeeProjectDAO.getProjectNamesJSON()).thenReturn(project);
		List<Project> prj = employeeProjectService.getProjectNamesJSON();
		Assert.assertNotSame(prj, null);
	}
	@Test
	public void getProjectByIdTest1() throws Exception{
		Mockito.when(employeeProjectDAO.getProjectById(0)).thenReturn("Mindtree");
		String prj = employeeProjectService.getProjectById(0);
		Assert.assertEquals(project.get(0).getProjectName(), prj);	
	}
	
	@Test
	public void getProjectByIdTest2() throws Exception{
		Mockito.when(employeeProjectDAO.getProjectById(0)).thenReturn("SAP");
		String prj = employeeProjectService.getProjectById(0);
		Assert.assertNotNull(prj);
	}
	
	@Test
	public void getProjectByIdTest3() throws Exception{
		Mockito.when(employeeProjectDAO.getProjectById(0)).thenReturn("SAP");
		String prj = employeeProjectService.getProjectById(0);
		Assert.assertNotSame(prj, null);
	}
	
	@Test
	public void getprojectEmployeeListTest1() throws Exception{
		Mockito.when(employeeProjectDAO.getprojectEmployeeList(Mockito.any(String.class))).thenReturn(employee);
		List<Employee> emp = employeeProjectService.getprojectEmployeeList("prj2");
		Assert.assertEquals(emp, employee);	
	}
	
	@Test
	public void getprojectEmployeeListTest2() throws Exception{
		Mockito.when(employeeProjectDAO.getprojectEmployeeList(Mockito.any(String.class))).thenReturn(employee);
		List<Employee> emp = employeeProjectService.getprojectEmployeeList("prj2");
		Assert.assertNotNull(emp);	
	}
	
	@Test
	public void getprojectEmployeeListTest3() throws Exception{
		Mockito.when(employeeProjectDAO.getprojectEmployeeList(Mockito.any(String.class))).thenReturn(employee);
		List<Employee> emp = employeeProjectService.getprojectEmployeeList("prj2");
		Assert.assertNotSame(emp, null);
	}
	
	@Test
	public void updateTest1() throws Exception{
		Mockito.when(employeeProjectDAO.update(Mockito.any(Employee.class), Mockito.any(String.class))).thenReturn("Saved");
		Employee emp1 = new Employee();
		emp1.setEmployeeName("Usha");
		emp1.setStartDate("12/12/2020");
		emp1.setEndDate("12/12/2020");
		emp1.setProjectName("SAP");
		emp1.setSubTask("Developer");
		emp1.setEmployeeListSelected(null);
		emp1.setId(0);
		emp1.setProject(null);
		emp1.setProject_id(6);
		String upd = employeeProjectService.update(emp1, "SAP");
		Assert.assertEquals("Saved", upd);	
	}
	
	@Test
	public void updateTest2() throws Exception{
		Mockito.when(employeeProjectDAO.update(Mockito.any(Employee.class), Mockito.any(String.class))).thenReturn("Saved");
		Employee emp1 = new Employee();
		emp1.setEmployeeName("Usha");
		emp1.setStartDate("12/12/2020");
		emp1.setEndDate("12/12/2020");
		emp1.setProjectName("SAP");
		emp1.setSubTask("Developer");
		emp1.setEmployeeListSelected(null);
		emp1.setId(0);
		emp1.setProject(null);
		emp1.setProject_id(6);
		String upd = employeeProjectService.update(emp1, "SAP");
		Assert.assertNotNull(upd);	
	}
	

	
}
