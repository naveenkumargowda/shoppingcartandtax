	function loadDetails(){
		loadProjects();
	}
	
	function formValidation(){
		var prj = validateProject();
		var desc = validateDesc();
		var emp = validateEmployee();
		var startDate = validateStartDate();
		var endDate = validateEndDate();
		
		if(prj && desc & emp & startDate & endDate)
			return true;
		else
			return false;
			
	}
	
	
	function loadProjects(){
		$.ajax({url: "http://localhost:8081/EmployeeRelastionshipManagement/list/projectsJSON",
			success: function(result){
				var projectDd=$("#projectIdDropdown");
				var projects=result;
		    	for(i=0;i<projects.length;i++){
			    	var option = $("<option>");
			    	option.text = projects[i]["projectName"];
			    	projectDd.append(option);
		    	}
			}

		    });
			  
	}
	
	function loadEmployeesList(){
		var projectSelected = document.getElementById("projectIdDropdown").value;
		var urlEmp ="http://localhost:8081/EmployeeRelastionshipManagement/list/projectEmployeeList/" + projectSelected;
		$.ajax({url: urlEmp,
			success: function(result){
				var employeeDd=$("#empDropdown");
		    	debugger;
		    	employeeDd.html("");
		    	var employees=result;
		    	//var opt ="option";
		    	for(i=0;i<employees.length;i++){
			    	var option = $("<option>");
			    	option.text = employees[i]["employeeName"];
			    	employeeDd.append(option);
		    	}
			}

		    });
	}
	
	
	function validateDesc(){
		var f = $("#form");
		var error = $("#descError");
		var val = f["subTask"].value;
		error.html("");
		if(val == null || val == ""){
			error.$("Cannot be left blank");
			return false;
		}
		return true;
	}
	
	function validateProject(){
		var f = $("#form");
		var error = $("#projectError");
		var val = f["projectIdDropdown"].value;
		error.html("");
		if(val == null || val == ""){
			error.html("Cannot be left blank");
			return false;
		}
		return true;
	}
	
	function validateEmployee(){
		var f = $("#form");
		var error = $("#employeeError");
		var val = f["employeeListSelected"].value;
		error.html("");
		if(val == null || val == ""){
			error.html("Atleast one employee must be selected");
			return false;
		}
		return true;
	}
	
	function validateStartDate(){
		var f = $("#form");
		var error = $("#startDateError");
		var val = f["startDate"].value;
		var regex = "^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$";
		error.html("");
		if(val == null || val == ""){
			error.html("Cannot be left blank");
			return false;
		}
		else if(!val.match(regex)){
			error.html("proper format is dd/mm/yyyy");
			return false;
		}
		return true;
	}
	
	function validateEndDate(){
		var f = $("#form");
		var error = $("#endDateError");
		var val = f["endDate"].value;
		var regex = "^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$";
		error.html("");
		if(val == null || val == ""){
			error.html("Cannot be left blank");
			return false;
		}
		else if(!val.match(regex)){
			error.html("proper format is dd/mm/yyyy");
			return false;
		}	
		return true;
		
	}