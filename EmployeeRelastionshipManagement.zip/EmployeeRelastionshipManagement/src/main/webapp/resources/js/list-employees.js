	function loadProjects(){
		$.ajax({url: "http://localhost:8081/EmployeeRelastionshipManagement/list/projectsJSON",
			success: function(result){
				var projectDd = $("#projectIdDropdown");
		    	var projects=result;
		    	for(i=0;i<projects.length;i++){
		    		var option = $("<option>");
			    	option.text(projects[i]["projectName"]);
			    	projectDd.append(option);
		    	}
			}

		    });
	}
	
	function loadProjectEmployees(event){
 		var xhttp = new XMLHttpRequest();
		var projectSelected = document.getElementById("projectIdDropdown").value;
		var loadProjectEmployeesURL = "http://localhost:8081/EmployeeRelastionshipManagement/list/taskViewPageProcessREST/" + projectSelected;
		$.ajax({url: loadProjectEmployeesURL,
			success: function(result){
				var projectEmployees = result;
				console.log(projectEmployees);
				var finalProjectEmp={};
				for(i=0;i<projectEmployees.length;i++){
					var projEmp=projectEmployees[i];
					
					if(finalProjectEmp[[projectEmployees[i].startDate,projectEmployees[i].endDate,projectEmployees[i].subTask,projectEmployees[i].projectName]]){
						finalProjectEmp[[projectEmployees[i].startDate,projectEmployees[i].endDate,projectEmployees[i].subTask,projectEmployees[i].projectName]].push(projectEmployees[i]);
					}else{
						finalProjectEmp[[projectEmployees[i].startDate,projectEmployees[i].endDate,projectEmployees[i].subTask,projectEmployees[i].projectName]]=[projectEmployees[i]];
					}
					console.log("finalProjectEmp"+finalProjectEmp);
					
					
				}
				printElements(finalProjectEmp,projectSelected);
		    	}
		

		    });
	}

	
		function printElements(finalProjectEmp,projectSelected){
			debugger;
			console.log(finalProjectEmp);
			var parentElement = $("#content");
			parentElement.html("");
			for(var key in finalProjectEmp){
				
				if(projectSelected === "All projects"){
					debugger;
					var childProjectLabel = $("<label>");
					childProjectLabel.html("Project Name: " + finalProjectEmp[key][0].projectName);
					parentElement.append(childProjectLabel);
					var br0 = $("<br>");
					parentElement.append(br0);
				
				
				}
				
				var childElementLabelTask = $("<label>");
				var appendChildElementLabelTask = parentElement.append(childElementLabelTask);
				childElementLabelTask.html("Task Description: " + finalProjectEmp[key][0].subTask);
				var br1 = $("<br>");
				parentElement.append(br1);
				
				

				
				var childElementLabelStrDt = $("<label>");
				var appendChildElementLabelStrDt = parentElement.append(childElementLabelStrDt);
				childElementLabelStrDt.html("Task Start Date: " + finalProjectEmp[key][0].startDate);
				var br2 = $("<br>");
				parentElement.append(br2);
				
				var childElementLabelEndDt = $("<label>");
				var appendChildElementLabelEndDt = parentElement.append(childElementLabelEndDt);
				childElementLabelEndDt.html("Task End Date: " + finalProjectEmp[key][0].endDate);
				var br2 = $("<br>");
				parentElement.append(br2);
				
				var table = $("<table>").attr('border' , 1);
				var tableBody = $("<tbody>");
				table.append(tableBody);
				
				var tr0 = $("<tr>");
				tableBody.append(tr0);
				
				var th1_1 = $("<th>");
				th1_1.html("MID");
				tr0.append(th1_1);

				
				var th2_1 = $("<th>");
				th2_1.html("Employee Name");
				tr0.append(th2_1);
				
				
				for(i=0;i<finalProjectEmp[key].length;i++){
					console.log(finalProjectEmp[key][i].id)
					
					var tr1 = $("<tr>");
					tableBody.append(tr1);
					
					var td1_1 = $("<td>");
					td1_1.html(finalProjectEmp[key][i].id);
					tr1.append(td1_1);

					
					var td2_1 = $("<td>");
					td2_1.html(finalProjectEmp[key][i].employeeName);
					tr1.append(td2_1);

				} 
				parentElement.append(table);
			}
			
		}
		