package com.springhibernate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.springhibernate.DAO.EmployeeProjectDAO;
import com.springhibernate.entity.Employee;
import com.springhibernate.entity.Project;

@Service
public class EmployeeProjectServiceImpl implements EmployeeProjectService {

	@Autowired
	EmployeeProjectDAO employeeProjectDAO;
	
	@Transactional(isolation=Isolation.SERIALIZABLE , propagation=Propagation.REQUIRED)
	public String save(Employee emp, String project) throws Exception {
			return employeeProjectDAO.save(emp , project);
	}
	
	@Transactional(isolation=Isolation.SERIALIZABLE , propagation=Propagation.REQUIRED)
	public String update(Employee emp, String project) throws Exception {
		return employeeProjectDAO.update(emp , project);
		
	}

	@Transactional(isolation=Isolation.SERIALIZABLE , propagation=Propagation.REQUIRED)
	public List<Employee> getEmployeeList(String projectName) throws Exception {
		return employeeProjectDAO.getEmployeeList(projectName);
	}

	@Transactional(isolation=Isolation.SERIALIZABLE , propagation=Propagation.REQUIRED)
	public List<Project> getProjectNamesJSON() throws Exception {
		return employeeProjectDAO.getProjectNamesJSON();
	}

	@Transactional(isolation=Isolation.SERIALIZABLE , propagation=Propagation.REQUIRED)
	public String getProjectById(int id) throws Exception {
		return employeeProjectDAO.getProjectById(id);
	}

	@Transactional(isolation=Isolation.SERIALIZABLE , propagation=Propagation.REQUIRED)
	public List<Employee> getprojectEmployeeList(String projectName) throws Exception {
		return employeeProjectDAO.getprojectEmployeeList(projectName);
	}


}
