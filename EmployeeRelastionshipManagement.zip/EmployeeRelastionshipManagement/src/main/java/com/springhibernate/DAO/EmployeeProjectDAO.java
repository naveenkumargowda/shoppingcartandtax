package com.springhibernate.DAO;

import java.util.List;

import com.springhibernate.entity.Employee;
import com.springhibernate.entity.Project;

public interface EmployeeProjectDAO {

	public String save(Employee emp, String project) throws Exception;

	public String update(Employee emp, String project) throws Exception;

	public List<Employee> getEmployeeList(String projectName) throws Exception;

	public List<Project> getProjectNamesJSON() throws Exception;

	public String getProjectById(int id) throws Exception;

	public List<Employee> getprojectEmployeeList(String projectName) throws Exception;
	

}
