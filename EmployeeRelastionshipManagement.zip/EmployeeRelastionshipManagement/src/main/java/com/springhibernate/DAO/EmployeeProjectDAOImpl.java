package com.springhibernate.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springhibernate.entity.Employee;
import com.springhibernate.entity.Project;

@Repository
public class EmployeeProjectDAOImpl implements EmployeeProjectDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	private Project proj ;
	
	private static Logger logger = Logger.getLogger(EmployeeProjectDAOImpl.class.getName());
	
	
	public String save(Employee emp, String project) throws Exception {
		Session currentSession = sessionFactory.openSession();
		logger.info("Saving the data into Data Base");
		logger.info("===>>> Employee" + emp);
		logger.info("===>>> Project " + project);
		try{
			proj = new Project(project);
			proj.addEmployee(emp);
	
			currentSession.save(emp);
			currentSession.saveOrUpdate(proj);
			logger.info("Done saving into Data Base!!");
		}catch(Exception exc){
			throw new Exception("Exception occured : "+exc.getMessage());
		}
		
		return "Saved";
	}

	
	//Getting the list of projects from data base ... This is for displaying in the drop down list "Projects" field
	public List<Project> getProjectNamesJSON() throws Exception {
		Session currentSession = sessionFactory.getCurrentSession();
		Query theQuery = null;
		try{
			theQuery = currentSession.createQuery("from Project");
		}
		catch (Exception exc) {
			//exc.printStackTrace();
			throw new Exception("Exception occured : "+exc.getMessage());
		}
		logger.info("Method : getProjectNamesJSON() --> Project list fetched from data base " + theQuery.list().toString());
		return theQuery.list();
	}
	
	//Getting the list of employees based on project selection ... This is for displaying in the drop down list "Who should do this?" field
	public List<Employee> getprojectEmployeeList(String projectName) throws Exception {
		Session currentSession = sessionFactory.getCurrentSession();
		List<Employee> empList = new ArrayList<Employee>();
		try{
			Integer theId = getProjectIdByName(projectName);
			//logger.info("Method : getprojectEmployeeList(String projectName) --> Project Id for project " + projectName + " is " + theId );
			Query theQuery = currentSession.createQuery("from Employee where project_id=:theProjectId");
			theQuery.setParameter("theProjectId", theId);
			empList = theQuery.list();
			
		}catch(Exception exc){
			//exc.printStackTrace();
			throw new Exception("Exception occured : "+exc.getMessage());
		}
		logger.info("Method : getprojectEmployeeList(String projectName) --> Employee list after choosing the project from drop down " + empList.toString());
		return empList;
	}
	
	

	//Saving the mapping of employee and project into data base
	public String update(Employee emp, String project) throws Exception {
		
		Session currentSession = sessionFactory.getCurrentSession();
		logger.info("Saving employee association with project into data base...");
		
		//Getting the id of the project selected from front end
		Query theQuery = currentSession.createQuery("select id from Project where projectName=:projectReceived");
		theQuery.setParameter("projectReceived", project);
		int theProjectId = (Integer) theQuery.list().get(0);
		System.out.println("===>>> project ID and project name :" + theProjectId + " " + project);
		logger.info("Method - update(Employee emp, String project) --> project ID and project name :" + theProjectId + " " + project);
		
		//Getting project object from DB
		proj = currentSession.get(Project.class , theProjectId); 
		logger.info("Method - update(Employee emp, String project) --> Project from Data base" + proj);
		
		try{
		
		for(String employeeName : emp.getEmployeeListSelected()){
		
				Query theQueryemp = currentSession.createQuery("select id from Employee where employeeName=:employeeReceived");
				theQueryemp.setParameter("employeeReceived", employeeName);
				int theEmployeeId = (Integer) theQueryemp.list().get(0);
				logger.info("Method - update(Employee emp, String project) --> Employee ID and Employee name :" + theEmployeeId + " " + employeeName);
				
				Employee empObject = new Employee(employeeName, emp.getSubTask(), emp.getStartDate(), emp.getEndDate());
				logger.info("Method - update(Employee emp, String project) --> Employee from Data base" + empObject);
				
				String startDateFormat = DateToStrinConvertorWithFormat(emp.getStartDate());
				String endDateFormat = DateToStrinConvertorWithFormat(emp.getEndDate());
		
				Query theQueryEmpProj = currentSession.createQuery("update Employee set subTask=:subTaskReceived , startDate=" + "STR_TO_DATE('" + startDateFormat + "','%d,%m,%Y')" + " , endDate=" + "STR_TO_DATE('" + endDateFormat + "','%d,%m,%Y')" + " , project_id=:project_idReceived where id=:idReceived");
				theQueryEmpProj.setParameter("subTaskReceived", emp.getSubTask() );
				theQueryEmpProj.setParameter("project_idReceived", theProjectId );
				theQueryEmpProj.setParameter("idReceived", theEmployeeId );
				
				theQueryEmpProj.executeUpdate();
			}
		}catch(Exception exc){
			//exc.printStackTrace();	
			throw new Exception("Exception occured : "+exc.getMessage());
		}
		logger.info("Saving employee association with project into data base is successfull!!");
		return "Saved";
	}

	//Getting the employee list from data base to display in 'TASK VIEW' page
	public List<Employee> getEmployeeList(String projectName) throws Exception  {
		Session currentSession = sessionFactory.getCurrentSession();
		
		List<Employee> empList = new ArrayList<Employee>();
		try{
		if(projectName.equals("All projects")){
			Query theQueryEmp = currentSession.createQuery("from Employee where not(subTask='') and not(startDate='') and not(endDate='')  order by project_id asc");
			empList = theQueryEmp.list();
			for(Employee emp : empList){
			String projectNameExtracted = getProjectById(emp.getProject_id());
			emp.setProjectName(projectNameExtracted);
			System.out.println("empList from DB " + empList);
			logger.info("Method - getEmployeeList(String projectName) --> empList from DB to view in Task View Page for 'All Project' option " + empList);
			}
		}
		else{
				
				Query theQuery = currentSession.createQuery("select id from Project where projectName=:projectName");
				theQuery.setParameter("projectName", projectName);
				int theProjectId = (Integer) theQuery.list().get(0);
				System.out.println("===>>> project ID and project name :" + theProjectId + " " + projectName);
				logger.info("Method - getEmployeeList(String projectName) --> project ID and project name from DB to view in Task View Page :" + theProjectId + " " + projectName);
		
				Query theQueryEmp = currentSession.createQuery("from Employee where project_id=:project_idReceived and not(subTask='') and not(startDate='') and not(endDate='') ");
				theQueryEmp.setParameter("project_idReceived", theProjectId);
				empList = theQueryEmp.list();
				for(Employee emp : empList){
					emp.setProjectName(projectName);
				}
				logger.info("Method - getEmployeeList(String projectName) --> empList from DB to view in Task View Page for project "+ projectName  + "\n"+ empList);

		}
		}catch(Exception exc){
			//exc.printStackTrace();
			throw new Exception("Exception occured : "+exc.getMessage());
		}
		
		return empList;
	}


	//Getting the project name by id from data base
	public String getProjectById(int id) throws Exception {
		Session currentSession = sessionFactory.getCurrentSession();
		Query theQuery = null;
		String projectName = null;
		try{
		theQuery = currentSession.createQuery("select projectName from Project where id=:prjId");
		theQuery.setParameter("prjId", id);
		projectName = (String) theQuery.list().get(0);
		}catch (Exception exc) {
			//exc.printStackTrace();
			throw new Exception("Exception occured : "+exc.getMessage());
		}
		
		System.out.println("PROJECT : with project Id " + id + " is " + projectName);
		logger.info("PROJECT Id : with project name " + projectName + " is " + id);
		return projectName;
	}
	
	//Getting the id by project name from data base
	public Integer getProjectIdByName(String projectName) throws Exception{
		Session currentSession = sessionFactory.getCurrentSession();
		Query theQuery = null;
		int projectId = 0;
		try{
		theQuery = currentSession.createQuery("select id from Project where projectName=:projectNameReq");
		theQuery.setParameter("projectNameReq", projectName);
		projectId = (Integer) theQuery.list().get(0);
		logger.info("PROJECT : with project Id " + projectId + " is " + projectName);
		}catch (Exception exc) {
			//exc.printStackTrace();
			throw new Exception("Exception occured : "+exc.getMessage());
		}
		
		return projectId;
		
	}
	
	//For converting the dates to the required format to store into data base
	public String DateToStrinConvertorWithFormat(String theDate){
		String strDateFormat = theDate.replace("/", ",");
		return strDateFormat;
	}


}
