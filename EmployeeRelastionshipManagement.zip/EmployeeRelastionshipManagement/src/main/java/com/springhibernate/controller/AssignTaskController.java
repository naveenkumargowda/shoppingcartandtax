 package com.springhibernate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springhibernate.entity.Employee;
import com.springhibernate.service.EmployeeProjectService;

@Controller
public class AssignTaskController {
	
	
	@Autowired
	EmployeeProjectService employeeProjectService;
	
	@InitBinder
	public void initBinder(WebDataBinder dataBinder){
		StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);
		dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
	}
	
	
	@GetMapping("/homePage")
	public String homePage(Model model){
		
		model.addAttribute("successfullMsg");
		
		return "homepage";
	}

	
	@GetMapping("/assignTaskForm")
	public String assignTaskForm(Model model){
		
		Employee emp = new Employee();

		model.addAttribute("employee", emp);

		return "assign-task-form";
	}
	
	@PostMapping("/assignTaskFormProcess")
	public String assignTaskFormProcess(@ModelAttribute("employee") Employee emp , Model model , @RequestParam("project") String project ) throws Exception{
	
			employeeProjectService.update(emp , project);
			
			model.addAttribute("successfullMsg", "Details added successfully.");
	
			return "homepage";
	}	
	
	@GetMapping("/taskViewPage")
	public String taskViewPage(Model model){
		Employee emp = new Employee();
		
		model.addAttribute("employee", emp);
		
		return "list-employees";
	}
	
	@GetMapping("/taskViewPageProcess")
	public String taskViewPageProcess(Model model , @RequestParam("project") String projectName) throws Exception {
		
		List<Employee> empList = employeeProjectService.getEmployeeList(projectName);
		/*for(Employee emp : empList){
		System.out.println("EMPLOYEE LIST BASED ON PROJECT SELECTION " + emp);
		System.out.println();
		}*/

		model.addAttribute("employee", empList);
		
		return "list-employees";
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
	
}

