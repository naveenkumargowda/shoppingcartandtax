package com.springhibernate.entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;

import org.eclipse.jdt.internal.compiler.ast.FalseLiteral;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.springhibernate.service.EmployeeProjectService;
import com.springhibernate.utility.DateUtils;

@Entity
@Table(name="employee")
@Component
@JsonIgnoreProperties(ignoreUnknown=true)
public class Employee {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="employee_name")
	private String employeeName;
	
	@Column(name="sub_task")
	private String subTask;
	
	@Column(name="start_date")
	private String startDate;
	
	@Column(name="end_date")
	private String endDate;
	
	@ManyToOne(cascade = { CascadeType.DETACH , CascadeType.MERGE ,CascadeType.PERSIST , CascadeType.REFRESH })
	@JoinColumn(name="project_id" , insertable=false , updatable=false)
	private Project project;
	
	public Project getProject() {
		return project;
	}


	public void setProject(Project project) {
		this.project = project;
	}

	@Transient
	@JsonIgnore
	private String employeeList[] = new String[5];
	
	@Transient
	@JsonIgnore
	private List<String> employeeListSelected = new ArrayList<String>(); 

	public Employee(){

	}
	

	public int getId() {
		return id;
	}

	public Employee(String employeeName, String subTask, String startDate, String endDate) {
		this.employeeName = employeeName;
		this.subTask = subTask;
		this.startDate = startDate;
		this.endDate = endDate;
	}


	public Employee(int id, String employeeName, String subTask) {
		this.id = id;
		this.employeeName = employeeName;
		this.subTask = subTask;
	}
	
	
	public void setId(int id) {
		this.id = id;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getSubTask() {
		return subTask;
	}

	public void setSubTask(String subTask) {
		this.subTask = subTask;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String[] getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(String[] employeeList) {
		this.employeeList = employeeList;
	}

	public List<String> getEmployeeListSelected() {
		return employeeListSelected;
	}

	public void setEmployeeListSelected(List<String> employeeListSelected) {
		this.employeeListSelected = employeeListSelected;
	}

	@Column(name="project_id")
	@JsonIgnore
	private Integer project_id;
	
	@Transient
	private String projectName;

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public int getProject_id() {
		return project_id;
	}

	public void setProject_id(int project_id) {
		this.project_id = project_id;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", employeeName=" + employeeName + ", subTask=" + subTask + ", startDate="
				+ startDate + ", endDate=" + endDate + ", employeeList=" + Arrays.toString(employeeList)
				+ ", employeeListSelected=" + employeeListSelected + ", project_id=" + project_id + ", projectName="
				+ projectName + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(employeeList);
		result = prime * result + ((employeeListSelected == null) ? 0 : employeeListSelected.hashCode());
		result = prime * result + ((employeeName == null) ? 0 : employeeName.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + id;
		result = prime * result + ((projectName == null) ? 0 : projectName.hashCode());
		result = prime * result + ((project_id == null) ? 0 : project_id.hashCode());
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((subTask == null) ? 0 : subTask.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (!Arrays.equals(employeeList, other.employeeList))
			return false;
		if (employeeListSelected == null) {
			if (other.employeeListSelected != null)
				return false;
		} else if (!employeeListSelected.equals(other.employeeListSelected))
			return false;
		if (employeeName == null) {
			if (other.employeeName != null)
				return false;
		} else if (!employeeName.equals(other.employeeName))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (id != other.id)
			return false;
		if (projectName == null) {
			if (other.projectName != null)
				return false;
		} else if (!projectName.equals(other.projectName))
			return false;
		if (project_id == null) {
			if (other.project_id != null)
				return false;
		} else if (!project_id.equals(other.project_id))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (subTask == null) {
			if (other.subTask != null)
				return false;
		} else if (!subTask.equals(other.subTask))
			return false;
		return true;
	}


	

}