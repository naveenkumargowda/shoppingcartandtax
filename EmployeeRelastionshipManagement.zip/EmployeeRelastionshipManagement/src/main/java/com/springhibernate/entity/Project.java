package com.springhibernate.entity;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="project")
@Component
@JsonIgnoreProperties(ignoreUnknown=true)
public class Project {
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	@JsonIgnore
	int id;
	
	@Column(name="project_name")
	private String projectName;
	
	@OneToMany(fetch=FetchType.LAZY , cascade=CascadeType.ALL )
	@JoinColumn(name="project_id")
	@JsonIgnore
	List<Employee> employee;
	

	
	@Transient
	@JsonIgnore
	private List<String> projectsAvailable = new ArrayList<String>();
	
	public Project(){
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Project(String projectName) {
		this.projectName = projectName;
	}

	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}
	
	public List<String> getProjectsAvailable() {
		return projectsAvailable;
	}

	public void setProjectsAvailable(List<String> projectsAvailable) {
		this.projectsAvailable = projectsAvailable;
	}

	@Override
	public String toString() {
		return "Project [id=" + id + ", projectName=" + projectName + "]";
	}
	
	//Adding the employee to the employee list
	public void addEmployee(Employee emp){
		
		if(employee==null){
			employee = new ArrayList<Employee>();
		}

		employee.add(emp);	
		emp.setProject(this); //creating bi-directional link
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((employee == null) ? 0 : employee.hashCode());
		result = prime * result + id;
		result = prime * result + ((projectName == null) ? 0 : projectName.hashCode());
		result = prime * result + ((projectsAvailable == null) ? 0 : projectsAvailable.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		if (employee == null) {
			if (other.employee != null)
				return false;
		} else if (!employee.equals(other.employee))
			return false;
		if (id != other.id)
			return false;
		if (projectName == null) {
			if (other.projectName != null)
				return false;
		} else if (!projectName.equals(other.projectName))
			return false;
		if (projectsAvailable == null) {
			if (other.projectsAvailable != null)
				return false;
		} else if (!projectsAvailable.equals(other.projectsAvailable))
			return false;
		return true;
	}
	
	

}
