/*package com.springhibernate.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springhibernate.entity.Employee;
import com.springhibernate.entity.Project;
import com.springhibernate.service.EmployeeProjectService;

@RestController
@RequestMapping("/list")
public class RESTapis {
	
	@Autowired
	private EmployeeProjectService employeeProjectService;
	
	@GetMapping("/projectsJSON")
	public List<Project> projectListJSON(){
		
		List<Project> prjList = employeeProjectService.getProjectNamesJSON();
		
		return prjList;
	}

	@GetMapping("/taskViewPageProcessREST/{projectName}")
	public List<Employee> taskViewPageProcess(@PathVariable("projectName") String projectName){
		
		List<Employee> empList = employeeProjectService.getEmployeeList(projectName);
		
		return empList;
	}
	
	@GetMapping("/projectEmployeeList/{projectName}")
	public List<Employee> projectEmployeeList(@PathVariable("projectName") String projectName){
		
		List<Employee> empList = employeeProjectService.getprojectEmployeeList(projectName);

		return empList;
	
	}
	
	
}
*/