package com.springhibernate.aop;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import com.springhibernate.entity.Employee;
import com.springhibernate.entity.Project;

@Aspect
@Component
public class LoggingAspects {
	

	
	@Pointcut("execution(* com.springhibernate.DAO.*.*(..))")
	public void forDAOPackage() {}
	
	@Pointcut("execution(* com.springhibernate.service.*.*(..))")
	public void forServicePackage() {}
	
	//This method is used to get the details of method signature and arguments passed in target methods
	//arguments : 1st - JointPoint 
	//2nd - string to differentiate the type of advice (before/after)
	//3rd and 4th - to control the displaying of methodSignature and argument values respectively
	public MethodSignature getMethodSignatureAndArguments(JoinPoint theJointPoint , String str , boolean metSig , boolean arguments){
		MethodSignature methodSig = (MethodSignature) theJointPoint.getSignature();
		if(metSig == true){
		//display the method signature
		System.out.println("===> ADVICE : " + str + " invoking method" + methodSig);
		}else
			;
		
		//display method arguments
		Object[] args = theJointPoint.getArgs();
		if(arguments == true){
			if(args.length>0){
			System.out.println("===> ARGUMENT : for method " + methodSig);
			for(Object tempArg : args){
				System.out.println("===> " + tempArg);
				}
			}
			else
				System.out.println("===> No ARGUMENTS passed for method " + methodSig );
			}
		else 
			;
		
	return methodSig;
	}
	
	//before advice for all DAO and service methods
	@Before("forDAOPackage() || forServicePackage()")
	public void beforeDAOServiceMethodsExecution(JoinPoint theJointPoint){
		System.out.println("***************************************************************************");
		
		getMethodSignatureAndArguments(theJointPoint , "Before" , true , true);
		
		System.out.println("***************************************************************************");

	}
		
	
	//after advice for DAOImpl getProjectNamesJSON method
	@AfterReturning(pointcut = "execution(* com.springhibernate.DAO.EmployeeProjectDAOImpl.getProjectNamesJSON(*))" , returning = "result")
	public void afterDAOProjectListMethodsExecution(JoinPoint theJointPoint , List<Project> result){
		System.out.println("***************************************************************************");
		
		MethodSignature methodSig = getMethodSignatureAndArguments(theJointPoint , "After" , true , false);
		
		System.out.println("===> ADVICE : After executing method " + methodSig + "return values are");

		System.out.println(result);
		
		System.out.println("***************************************************************************");
		
	}
	
	//after advice for DAOImpl getprojectEmployeeList method
	@AfterReturning(pointcut = "execution(* com.springhibernate.DAO.EmployeeProjectDAOImpl.getprojectEmployeeList(..))" , returning = "result")
	public void afterDAOEmployeeListMethodsExecution(JoinPoint theJointPoint , List<Employee> result){
		System.out.println("***************************************************************************");
		
		MethodSignature methodSig = getMethodSignatureAndArguments(theJointPoint , "After" , true , false);
		
		System.out.println("===> ADVICE : After executing method " + methodSig + "return values are");

		System.out.println(result);
		
		System.out.println("***************************************************************************");
		
	}

}
