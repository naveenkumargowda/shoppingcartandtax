package com.org.mindtree.taxregister.services;

import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.org.mindtree.taxregister.dao.AccountDao;
import com.org.mindtree.taxregister.model.Account;

/**
 * @author M1054967
 *
 */
@Service
public class TaxServiceImpl implements TaxService {

	Logger logger = Logger.getLogger(TaxServiceImpl.class.getName());

	@Autowired
	AccountDao accountDao;

	public TaxServiceImpl(AccountDao myDao) {
		this.accountDao = myDao;
	}

	/**
	 * Usage of Transaction attributes and isolation level
	 **/
	@Override
	@Transactional(isolation = Isolation.DEFAULT)
	public boolean saveAccount(Account account) {
		logger.info("saveAccount");
		return accountDao.saveAccount(account);
	}

	@Override
	public float totalTaxSum(String status, char zone) {
		logger.info("getTaxSum");
		return accountDao.getTaxSum(status, zone);
	}

	/**
	 * Usage of Transaction attributes and isolation level
	 **/
	@Override
	@Transactional(isolation = Isolation.DEFAULT)
	public List getZoneList() {
		logger.info("getZoneList");
		return accountDao.getZoneList();
	}

	@Override
	public float getTaxValues(String zone, String description, String status, int year, float area) {
		logger.info("getTax");
		float uav = accountDao.getTaxDetails(description, zone, status);
		float Total_5 = getTaxTotal(year, area, uav);
		return Total_5;
	}

	public float getTaxTotal(int year, float built_Up_Area, float unit_Area_Value) {
		logger.info("getTaxTotal");
		float Total_1 = built_Up_Area * unit_Area_Value * 10;
		int building_Age = (Calendar.getInstance().get(Calendar.YEAR)) - year;
		float depreciation;
		if (building_Age > 60) {
			depreciation = (float) (Total_1 * 0.6);
		} else {
			depreciation = (Total_1 / 100) * building_Age;
		}
		float Total_2 = Total_1 - depreciation;
		float Total_3 = (float) (Total_2 + (Total_2 * 0.2));
		float Total_4 = (float) (Total_3 + (Total_3 * 0.24));
		float Total_5 = Total_3 + Total_4;
		return Total_5;
	}

}
