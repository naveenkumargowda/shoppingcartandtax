package com.org.mindtree.taxregister.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.apache.log4j.Appender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.org.mindtree.taxregister.dao.AccountDao;
import com.org.mindtree.taxregister.model.Account;
import com.org.mindtree.taxregister.services.TaxServiceImpl;

public class TaxServiceImplTest {

	Logger logger = Logger.getLogger(TaxServiceImplTest.class.getName());
	private final Logger loggerTest = Logger.getRootLogger();
	private final Appender appender = mock(Appender.class);

	private TaxServiceImpl taxServiceImpl;
	private AccountDao accountDao;

	@Before
	public void init() {
		logger.info("inits");
		accountDao = Mockito.mock(AccountDao.class);
		taxServiceImpl = new TaxServiceImpl(accountDao);
		loggerTest.addAppender(appender);
	}

	@After
	public void cleanUp() {
		logger.info("cleanUp");
		taxServiceImpl = null;
		loggerTest.removeAppender(appender);
	}

	@Test
	public void saveAccountTest() {
		logger.info("saveAccountTest");
		Account account = new Account();
		account.setAssessmentYear(2020);
		account.setOwnerName("Ankur");
		account.setEmail("AnkurKumar.Biswas@mindtree.com");
		account.setAddress("211 rd, WB");
		account.setZonalClassification("A");
		account.setDescription("RCC buildings");
		account.setStatus("Owner");
		account.setConstructYear(2013);
		account.setArea(1450);
		account.setTax(3440);
		Mockito.when(accountDao.saveAccount(account)).thenReturn(true);
		assertEquals(true, taxServiceImpl.saveAccount(account));
	}

	@Test
	public void getTaxTotalTest() {
		logger.info("getTaxTotalTest");
		int year = 2016;
		float area = 130;
		float uav = 5.90f;
		assertEquals(2416.9f, taxServiceImpl.getTaxTotal(year, area, uav));
	}

	@Test
	public void getTaxTest() {
		logger.info("Positive test case");
		String zone = "A";
		String description = "RCC buildings";
		String status = "Owner";
		int year = 2012;
		float area = 200;
		float uav = 8.50f;
		Mockito.when(accountDao.getTaxDetails(description, zone, status)).thenReturn(uav);
		assertEquals(2416.9f, taxServiceImpl.getTaxValues(zone, description, status, year, area));
	}

	@Test
	public void getTaxSumTest() {
		logger.info("getTaxSumTest");
		String status = "Tenanted";
		float sum = 1125;
		char zonal = 'B';
		Mockito.when(accountDao.getTaxSum(status, zonal)).thenReturn(sum);
		assertEquals(2416.0f, taxServiceImpl.totalTaxSum(status, zonal));
	}

	@Test(expected = NullPointerException.class)
	public void TestAccountEntityNPE() {
		Account account = null;
		account.setAssessmentYear(2010);
	}

	@Test
	public void saveAccountNegTest() {
		logger.info("Negative Flow method");
		Account account = new Account();
		account.setAssessmentYear(2020);
		account.setOwnerName("Somojit");
		account.setEmail("seal.somojit@gmail.com");
		account.setAddress("Hyderabad, Gulshan Bhaban");
		account.setZonalClassification("B");
		account.setDescription("RCC buildings");
		account.setStatus("Owner");
		account.setConstructYear(2012);
		account.setArea(2000);
		account.setTax(2000);
		Mockito.when(accountDao.saveAccount(account)).thenReturn(true);
		assertFalse(account.getOwnerName().equals("Nabanil"));
	}

	@Test
	public void loggerTest() {
		// when logging
		Logger.getLogger(Account.class).info("Test");

		// Checking Log message
		ArgumentCaptor<LoggingEvent> argument = ArgumentCaptor.forClass(LoggingEvent.class);
		verify(appender).doAppend(argument.capture());
		assertEquals(Level.INFO, argument.getValue().getLevel());
		assertEquals("Test", argument.getValue().getMessage());
		assertEquals("com.org.mindtree.taxregister.model.Account", argument.getValue().getLoggerName());
	}
}
