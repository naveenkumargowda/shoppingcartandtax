/**
 * 
 */
package com.org.mindtree.taxregister.services;

import java.util.List;

import com.org.mindtree.taxregister.model.Account;

/**
 * @author M1054967
 *
 */
public interface TaxService {

	public boolean saveAccount(Account account);

	float totalTaxSum(String status, char zonal);

	public List getZoneList();

	float getTaxValues(String zone, String description, String status, int year, float area);

}
