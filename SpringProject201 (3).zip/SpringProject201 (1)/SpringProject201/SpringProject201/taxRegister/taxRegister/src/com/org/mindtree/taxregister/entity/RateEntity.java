package com.org.mindtree.taxregister.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "rate")
public class RateEntity implements Serializable, Comparable<String> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "sno", unique = true, nullable = false)
	private Integer sno;

	@Column(name = "zone")
	private char zone;

	@Column(name = "status")
	private String status;

	@Column(name = "category1")
	private String category1;

	@Column(name = "category2")
	private String category2;

	@Column(name = "category3")
	private String category3;

	public Integer getSno() {
		return sno;
	}

	public void setSno(Integer sno) {
		this.sno = sno;
	}

	public char getZone() {
		return zone;
	}

	public void setZone(char zone) {
		this.zone = zone;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCategory1() {
		return category1;
	}

	public void setCategory1(String category1) {
		this.category1 = category1;
	}

	public String getCategory2() {
		return category2;
	}

	public void setCategory2(String category2) {
		this.category2 = category2;
	}

	public String getCategory3() {
		return category3;
	}

	public void setCategory3(String category3) {
		this.category3 = category3;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category1 == null) ? 0 : category1.hashCode());
		result = prime * result + ((category2 == null) ? 0 : category2.hashCode());
		result = prime * result + ((category3 == null) ? 0 : category3.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + zone;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RateEntity other = (RateEntity) obj;
		if (category1 == null) {
			if (other.category1 != null)
				return false;
		} else if (!category1.equals(other.category1))
			return false;
		if (category2 == null) {
			if (other.category2 != null)
				return false;
		} else if (!category2.equals(other.category2))
			return false;
		if (category3 == null) {
			if (other.category3 != null)
				return false;
		} else if (!category3.equals(other.category3))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (zone != other.zone)
			return false;
		return true;
	}

	@Override
	public int compareTo(String arg0) {
		return category1.compareTo(arg0);
	}
}
