package com.org.mindtree.taxregister.model;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * Account model class Containing validations
 */
public class Account {

	@Min(value = 1947, message = "Current Year should not be less than 1947.")
	@Digits(integer = 4, fraction = 0, message = " Assessment year should be 4 digits.")
	@NotNull(message = "Please Provide Assessment year.")
	private Integer assessmentYear;

	@NotEmpty(message = "Please Enter your name.")
	private String ownerName;

	@NotBlank(message = "Please Enter your E-mail.")
	@Email(message = "Enter correct E-Mail format")
	private String email;

	@NotEmpty(message = "Please provide your Address.")
	private String address;

	@NotNull(message = "Select Zone.")
	private String zonalClassification;

	@NotNull(message = "Select Building Type.")
	private String description;

	@NotNull(message = "Select Status.")
	private String status;

	@Min(value = 1947, message = "Construct Year should not be less than 1947.")
	@Max(value = 2020, message = "Construct Year can not be greater than current year.")
	@Digits(integer = 4, fraction = 0, message = "Construct Year should be 4 digits.")
	@NotNull(message = "Construct Year must be filled within 1947 - 2020")
	@NumberFormat(style = Style.NUMBER, pattern = "####")
	private int constructYear;

	@NotNull(message = "Please Enter Number")
	@NumberFormat(style = Style.NUMBER)
	private int area;

	@NotNull(message = "Tax calculated for the given details")
	@NumberFormat(style = Style.NUMBER)
	private float tax;

	public Account() {
		assessmentYear = 1947;
		ownerName = "";
		email = "";
		address = "";
		zonalClassification = "";
		description = "";
		status = "";
		constructYear = 0;
		area = 0;
		tax = 0;

	}

	public Account(Integer assessmentYear, String name, String email, String address, String zonalClassification,
			String description, String status, int constructYear, int area, float tax) {
		this.assessmentYear = assessmentYear;
		this.ownerName = name;
		this.email = email;
		this.zonalClassification = zonalClassification;
		this.description = description;
		this.status = status;
		this.constructYear = constructYear;
		this.area = area;
		this.tax = tax;
	}

	public Integer getAssessmentYear() {
		return assessmentYear;
	}

	public void setAssessmentYear(Integer assessmentYear) {
		this.assessmentYear = assessmentYear;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZonalClassification() {
		return zonalClassification;
	}

	public void setZonalClassification(String zonalClassification) {
		this.zonalClassification = zonalClassification;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getConstructYear() {
		return constructYear;
	}

	public void setConstructYear(int constructYear) {
		this.constructYear = constructYear;
	}

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}

	public float getTax() {
		return tax;
	}

	public void setTax(float tax) {
		this.tax = tax;
	}

}
