package com.org.mindtree.taxregister.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.mock;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.org.mindtree.taxregister.dao.AccountDao;
import com.org.mindtree.taxregister.services.TaxServiceImpl;

/*Class to cover negative testing*/
public class TaxServiceImplNegativeFlow {
	Logger logger = Logger.getLogger(TaxServiceImplNegativeFlow.class.getName());
	private final Logger test = Logger.getRootLogger();
	private final Appender appender = mock(Appender.class);
	private TaxServiceImpl taxServiceImpl;
	private AccountDao accountDao;

	@Before
	public void init() {
		logger.info("init method");
		accountDao = Mockito.mock(AccountDao.class);
		taxServiceImpl = new TaxServiceImpl(accountDao);
		test.addAppender(appender);
	}

	@After
	public void cleanUp() {
		logger.info("cleanUp method");
		taxServiceImpl = null;
		test.removeAppender(appender);
	}

	@Test
	public void getTaxTotalNegTest() {
		logger.info("getTaxTotalNegTest method");
		int year = 2020;
		float area = 140;
		float uav = 19.20f;
		assertFalse(taxServiceImpl.getTaxTotal(year, area, uav) == 6115.2f);
	}

	@Test
	public void getTaxNegTest() {
		logger.info("Negative Flow");
		String zone = "B";
		String description = "RCC buildings";
		String status = "Owner";
		int year = 2020;
		float area = 120;
		float uav = 8.20f;
		Mockito.when(accountDao.getTaxDetails(description, zone, status)).thenReturn(uav);
		assertFalse(taxServiceImpl.getTaxValues(zone, description, status, year, area) == 6115.2f);
	}

	@Test
	public void getTaxSumNegTest() {
		logger.info("getTaxSumTest method");
		String status = "Owner";
		float sum = 1245;
		char zonal = 'B';
		Mockito.when(accountDao.getTaxSum(status, zonal)).thenReturn(sum);
		assertFalse(taxServiceImpl.totalTaxSum(status, zonal) != 1445.0f);
	}
}
