/**
 * 
 */
package com.org.mindtree.taxregister.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.org.mindtree.taxregister.entity.AccountEntity;
import com.org.mindtree.taxregister.entity.RateEntity;
import com.org.mindtree.taxregister.model.Account;

/**
 * @author M1054967
 *
 */
@Repository
public class AccountDaoImpl implements AccountDao {

	@Autowired
	private SessionFactory sessionFactory;
	Logger logger = Logger.getLogger(AccountDaoImpl.class.getName());

	@Override
	public boolean saveAccount(Account account) {
		logger.info("In Report page controller");
		boolean flag = true;
		AccountEntity accountEntity = new AccountEntity();
		RateEntity rateEntity = new RateEntity();
		accountEntity.setAssessmentYear(account.getAssessmentYear());
		accountEntity.setOwnerName(account.getOwnerName());
		accountEntity.setEmail(account.getEmail());
		accountEntity.setAddress(account.getAddress());
		accountEntity.setZonalClassification(account.getZonalClassification());
		accountEntity.setDescription(account.getDescription());
		accountEntity.setStatus(account.getStatus());
		accountEntity.setConstructYear(account.getConstructYear());
		accountEntity.setArea(account.getArea());
		accountEntity.setTax(account.getTax());

		try {
			logger.info("Opening Hibernate session");
			Session session;
			int sno;
			try {
				session = sessionFactory.getCurrentSession();
				String hql = "SELECT sno FROM rate WHERE zone = '" + account.getZonalClassification()
						+ "' AND status = '" + account.getStatus() + "'";
				Query query = session.createNativeQuery(hql);
				sno = (int) query.getSingleResult();
				rateEntity.setSno(sno);
				accountEntity.setSno(rateEntity);
			} catch (HibernateException e) {
				session = sessionFactory.openSession();
			}
			logger.info("Saving data into DB");
			session.save(accountEntity);
		} catch (Exception e) {
			logger.error("Error occured at save" + e);
			flag = false;
		}
		return flag;
	}

	@Override
	public float getTaxDetails(String description, String zone, String owner) {
		logger.info("Int getTaxDetails");
		float tax = 0;
		String category;
		try {
			logger.info("Opening Hibernate session");
			Session session;
			try {
				session = sessionFactory.getCurrentSession();
			} catch (HibernateException e) {
				session = sessionFactory.openSession();
			}
			Transaction t = session.beginTransaction();
			String hql = "SELECT category_number FROM category WHERE category_name = '" + description + "'";
			Query query = session.createNativeQuery(hql);
			category = (String) query.getSingleResult();
			String hql1 = "SELECT " + category + " AS UAU FROM rate WHERE zone = '" + zone + "' AND status = '" + owner
					+ "'";
			query = session.createNativeQuery(hql1);
			tax = (float) query.getSingleResult();
			t.commit();
			session.close();
			logger.info("Closing Hibernate session");
		} catch (Exception ex) {
			logger.error("Unable to connect DB");
		}
		return tax;
	}

	@Override
	public List getZoneList() {
		logger.info("Init getZoneList");
		AccountEntity accountEntity = new AccountEntity();
		RateEntity rateEntity = new RateEntity();
		List list = null;
		try {
			logger.info("Opening Hibernate session");
			Session session;
			try {
				session = sessionFactory.getCurrentSession();
			} catch (HibernateException e) {
				session = sessionFactory.openSession();
			}
			String hql = "SELECT distinct r.zone FROM rate r";
			Query query = session.createNativeQuery(hql);
			list = query.list();
		} catch (Exception ex) {
			logger.error("Unable to connect DB");
		}
		return list;
	}

	/**
	 * Method for getting tax sum for reporting
	 */
	@Override
	public float getTaxSum(String status, char zonal) {
		logger.info("Init getTaxSum");
		float tax = 0;
		try {
			logger.info("Opening Hibernate session");
			Session session;
			try {
				session = sessionFactory.getCurrentSession();
			} catch (HibernateException e) {
				session = sessionFactory.openSession();
				logger.error("Exception occured." + e);
			}
			Transaction t = session.beginTransaction();
			String hql = "select round(sum(tax),2) as tax from account where status = '" + status
					+ "' and zonalClassification = '" + zonal + "'";
			Query query = session.createNativeQuery(hql);
			if (null != query && null != query.getSingleResult()) {
				tax = Float.valueOf(query.getSingleResult().toString());
			}
			t.commit();
			session.close();
			logger.info("Closing Hibernate session");
		} catch (Exception ex) {
			logger.error("Unable to connect Database");
		}
		return tax;
	}

}
