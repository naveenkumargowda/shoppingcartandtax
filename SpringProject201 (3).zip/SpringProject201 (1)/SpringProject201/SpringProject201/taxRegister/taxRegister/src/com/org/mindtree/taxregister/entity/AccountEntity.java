package com.org.mindtree.taxregister.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Entity class for AccountEntity Override hashCode() and equals() method
 * Implements Comparable and Serializable
 **/

@Entity
@Table(name = "account")
public class AccountEntity implements Serializable, Comparable<String> {

	private static final long serialVersionUID = 1L;

	@Column(name = "assessmentYear")
	private Integer assessmentYear;

	@Column(name = "ownerName")
	private String ownerName;

	@Id
	@Column(name = "email", unique = true, nullable = false)
	private String email;

	@Column(name = "address")
	private String address;

	@Column(name = "zonalClassification")
	private String zonalClassification;

	@Column(name = "description")
	private String description;

	@Column(name = "status")
	private String status;

	@Column(name = "constructYear")
	private int constructYear;

	@Column(name = "area")
	private int area;

	@Column(name = "tax")
	private float tax;

	@OneToOne(targetEntity = RateEntity.class, cascade = CascadeType.REMOVE)
	@JoinColumn(name = "sno", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private RateEntity sno;

	public AccountEntity() {

	}

	public RateEntity getSno() {
		return sno;
	}

	public void setSno(RateEntity sno) {
		this.sno = sno;
	}

	public Integer getAssessmentYear() {
		return assessmentYear;
	}

	public void setAssessmentYear(Integer assessmentYear) {
		this.assessmentYear = assessmentYear;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZonalClassification() {
		return zonalClassification;
	}

	public void setZonalClassification(String zonalClassification) {
		this.zonalClassification = zonalClassification;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getConstructYear() {
		return constructYear;
	}

	public void setConstructYear(int constructYear) {
		this.constructYear = constructYear;
	}

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}

	public float getTax() {
		return tax;
	}

	public void setTax(float tax) {
		this.tax = tax;
	}

	@Override
	public int hashCode() {
		final int number = 31;
		int final_result = 1;
		final_result = number * final_result + ((address == null) ? 0 : address.hashCode());
		final_result = number * final_result + area;
		final_result = number * final_result + ((assessmentYear == null) ? 0 : assessmentYear.hashCode());
		final_result = number * final_result + constructYear;
		final_result = number * final_result + ((description == null) ? 0 : description.hashCode());
		final_result = number * final_result + ((email == null) ? 0 : email.hashCode());
		final_result = number * final_result + ((ownerName == null) ? 0 : ownerName.hashCode());
		final_result = number * final_result + ((status == null) ? 0 : status.hashCode());
		long temp;
		temp = Double.doubleToLongBits(tax);
		final_result = number * final_result + (int) (temp ^ (temp >>> 32));
		final_result = number * final_result + ((zonalClassification == null) ? 0 : zonalClassification.hashCode());
		return final_result;
	}

	@Override
	public boolean equals(Object value) {
		if (this == value)
			return true;
		if (value == null)
			return false;
		if (getClass() != value.getClass())
			return false;
		AccountEntity other = (AccountEntity) value;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (area != other.area)
			return false;
		if (assessmentYear == null) {
			if (other.assessmentYear != null)
				return false;
		} else if (!assessmentYear.equals(other.assessmentYear))
			return false;
		if (constructYear != other.constructYear)
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (ownerName == null) {
			if (other.ownerName != null)
				return false;
		} else if (!ownerName.equals(other.ownerName))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (Double.doubleToLongBits(tax) != Double.doubleToLongBits(other.tax))
			return false;
		if (zonalClassification == null) {
			if (other.zonalClassification != null)
				return false;
		} else if (!zonalClassification.equals(other.zonalClassification))
			return false;
		return true;
	}

	@Override
	public int compareTo(String arg0) {
		return zonalClassification.compareTo(arg0);
	}

}
