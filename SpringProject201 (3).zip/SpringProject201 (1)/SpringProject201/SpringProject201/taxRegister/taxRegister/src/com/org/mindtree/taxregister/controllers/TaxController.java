/**
 * 
 */
package com.org.mindtree.taxregister.controllers;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.TransactionRolledbackException;
import javax.validation.Valid;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.org.mindtree.taxregister.model.Account;
import com.org.mindtree.taxregister.services.TaxService;

/**
 * @author M1054967 
 */

@ControllerAdvice
@Controller
public class TaxController {

	@Autowired
	TaxService taxService;

	/**
	 * Logger console and storing in log file
	 **/
	public static final Logger logger = Logger.getLogger(TaxController.class.getName());

	/**
	 * verifying the string for white spaces
	 **/
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		StringTrimmerEditor ste = new StringTrimmerEditor(true);
		dataBinder.registerCustomEditor(String.class, ste);
	}

	/**
	 * Home Page Controller
	 **/
	@RequestMapping("/")
	public String homePage(Locale locale) {
		logger.info("Presenting Home page " + locale);
		return "index";

	}

	/**
	 * Form page Controller
	 **/
	@RequestMapping("/Form")
	public String taxForm(Model value) {
		logger.info("Presenting Tax Form page");
		addValuesToDropdown(value);
		value.addAttribute("account", new Account());
		logger.info("Presenting tax form");
		return "newForm";
	}

	/**
	 * Method to add data to the dropdown
	 **/
	public void addValuesToDropdown(Model model) {
		try {
			if (null != model) {
				Map<String, String> status = new HashMap<String, String>();
				logger.info("Adding dropdown data");
				status.put("Owner", "Owner");
				status.put("Tenanted", "Tenanted");
				model.addAttribute("statusMap", status);

				Map<String, String> description = new HashMap<String, String>();
				description.put("RCC buildings", "RCC buildings");
				description.put("RCC buildings with cement or red-oxide flooring",
						"RCC buildings with cement or red-oxide flooring");
				description.put("Tiled/Sheet of all kinds", "Tiled/Sheet of all kinds");
				model.addAttribute("descripMap", description);

				List zone = taxService.getZoneList();
				model.addAttribute("zoneMap", zone);
			} else {
				throw new Exception();
			}
		} catch (Exception e) {
			logger.error("Exception occured." + e);
		}
	}

	/**
	 * Controller for report screen
	 **/
	@RequestMapping("/report")
	public String reportPage(Model report) {
		try {
			if (null != report) {
				logger.info("In Report page controller");
				report.addAttribute("ownerA", taxService.totalTaxSum("Owner", 'A'));
				report.addAttribute("ownerB", taxService.totalTaxSum("Owner", 'B'));
				report.addAttribute("ownerC", taxService.totalTaxSum("Owner", 'C'));
				report.addAttribute("tenantedA", taxService.totalTaxSum("Tenanted", 'A'));
				report.addAttribute("tenantedB", taxService.totalTaxSum("Tenanted", 'B'));
				report.addAttribute("tenantedC", taxService.totalTaxSum("Tenanted", 'C'));
			} else {
				throw new Exception();
			}
		} catch (Exception e) {
			logger.error("Exception occured " + e);
		}
		return "report";
	}

	@RequestMapping(value = "/taxForm", method = RequestMethod.GET)
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String zonalClassification = request.getParameter("zonalClassification");
			String description = request.getParameter("description");
			String status = request.getParameter("status");
			int year = Integer.parseInt(request.getParameter("year"));
			float area = Float.parseFloat(request.getParameter("area"));
			float tax = taxService.getTaxValues(zonalClassification, description, status, year, area);
			response.getWriter().println(tax);
		} catch (NumberFormatException e) {
			logger.log(Level.INFO, "Number format error.");
			logger.error("exception occured. " + e);
		} catch (Exception e) {
			logger.error("exception occured. " + e);
		}

	}

	/**
	 * Controller for Save Form
	 **/
	@RequestMapping(value = "/saveForm", method = RequestMethod.POST)
	public String saveForm(@Valid @ModelAttribute("account") Account account, BindingResult result, Model value)
			throws ConstraintViolationException, TransactionRolledbackException {
		logger.info("save Form controller");
		if (result.hasErrors()) {
			addValuesToDropdown(value);
			return "newForm";
		} else {
			try {
				taxService.saveAccount(account);
				value.addAttribute("msg", "Tax details saved successfully!!!");
				logger.info("Tax details saved successfully!!!");
			} catch (DataIntegrityViolationException e) {
				value.addAttribute("msg", "Data already exists");
				logger.error("exception occured. " + e);
				addValuesToDropdown(value);
				return "newForm";
			} catch (Exception e) {
				value.addAttribute("msg", "Please check the details !");
				logger.error("exception occured. " + e);
				addValuesToDropdown(value);
				return "newForm";
			}
		}
		return "redirect:/";
	}

}
