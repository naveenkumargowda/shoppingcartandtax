/**
 * 
 */
package com.org.mindtree.taxregister.dao;

import java.util.List;

import com.org.mindtree.taxregister.model.Account;

/**
 * @author M1054967
 *
 */
public interface AccountDao {

	public boolean saveAccount(Account account);

	public float getTaxDetails(String description, String zone, String status);

	public List getZoneList();

	float getTaxSum(String status, char zonal);

}
