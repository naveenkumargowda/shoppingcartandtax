package com.org.mindtree.taxregister.test;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.org.mindtree.taxregister.controllers.TaxController;
import com.org.mindtree.taxregister.model.Account;
import com.org.mindtree.taxregister.services.TaxServiceImpl;

public class TaxControllerTest {

	MockMvc mockMvc;

	@InjectMocks
	TaxController taxController;

	@Autowired
	Account account;
	@Autowired
	HttpServletRequest request;
	@Autowired
	HttpServletResponse response;
	@Mock
	Model model;
	@Mock
	BindingResult result;
	@Mock
	TaxController taxController1;

	@Mock
	TaxServiceImpl taxService;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(taxController).build();
	}

	@Test
	public void homePage() throws Exception {

		mockMvc.perform(get("/")).andExpect(status().isOk());
		Locale locale = new Locale("en");
		assertNotNull(taxController.homePage(locale));

	}

	@Test
	public void testFormPage() throws Exception {

		mockMvc.perform(get("/Form")).andExpect(status().isOk());
		doNothing().when(taxController1).addValuesToDropdown(model);
		assertNotNull(taxController.taxForm(model));

	}

	@Test
	public void doGet() throws Exception {
		mockMvc.perform(get("/taxForm")).andExpect(status().isOk());
		when(taxService.getTaxValues(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),
				Mockito.anyFloat())).thenReturn(234.2f);
		doNothing().when(taxController1).doGet(request, response);
	}

	@Test
	public void saveForm() throws Exception {
		mockMvc.perform(post("/saveForm")).andExpect(status().isOk());
		assertNotNull(taxController.saveForm(account, result, model));

	}

}