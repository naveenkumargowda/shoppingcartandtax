package com.shopping.cart.services;

import java.util.List;
import java.util.Optional;

import com.shopping.cart.entity.Product;

public interface ProductService {
	
	public void insertProduct(Product pd);
	
	public List<Product> getAllProducts();
	
	public Optional<Product> getById(int id);
	
	public List<Product> getByName(String name);
	
	public List<Product> getByCategory(String category);
	
	
	

}
