package com.shopping.cart.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shopping.cart.entity.CartProduct;

@Repository 
public interface CartProductDao extends JpaRepository<CartProduct, Integer> {

}
