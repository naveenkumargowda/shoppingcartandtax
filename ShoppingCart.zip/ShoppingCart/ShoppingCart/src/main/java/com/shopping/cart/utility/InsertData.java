package com.shopping.cart.utility;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.shopping.cart.entity.Product;
import com.shopping.cart.entity.User;
import com.shopping.cart.services.ProductService;
import com.shopping.cart.services.UserService;

@Component
public class InsertData {

	@Autowired
	ProductService productservice;

	@Autowired
	UserService userService;

	@EventListener
	public void appReady(ApplicationReadyEvent event) {
		
		insertDefaultDataToProduct();
		insertDefaultDataToProd();
		insertDefaultDataToUser();
		Runtime.getRuntime().gc();
	}

	public void insertDefaultDataToProduct() {

		Product pd = new Product();

		JSONObject obj = new JSONObject();
		obj.put("genre", "Social_Science");
		obj.put("author", "Arihant");
		obj.put("publications", "Arihant_Publisher");

		pd.setName("General knowledge 2021");
		pd.setPrice(120);
		pd.setProductType(ProductType.BOOK.toString());
		//pd.setProductDetails(obj.toString().getBytes());
		pd.setProductDetails(obj.toString());
		productservice.insertProduct(pd);

		JSONObject obj1 = new JSONObject();
		obj1.put("genre", "Entrance_Exam_Preparation");
		obj1.put("author", "Mcgrawhill");
		obj1.put("publications", "Mcgrawhill_TP");

		Product pd1 = new Product();
		pd1.setName("Geography of India");
		pd1.setPrice(558);
		pd1.setProductType(ProductType.BOOK.toString());
		//pd1.setProductDetails(obj1.toString().getBytes());
		pd1.setProductDetails(obj1.toString());
		productservice.insertProduct(pd1);

		JSONObject obj2 = new JSONObject();
		obj2.put("genre", "Self-help");
		obj2.put("author", "Jaico");
		obj2.put("publications", "Jaico");
		Product pd2 = new Product();
		pd2.setName("Chanakya Neethi");
		pd2.setPrice(213);
		pd2.setProductType(ProductType.BOOK.toString());
	//	pd2.setProductDetails(obj2.toString().getBytes());
		pd2.setProductDetails(obj2.toString());
		productservice.insertProduct(pd2);

	}
	
	public void insertDefaultDataToProd()
	{
		Product pd = new Product();

		JSONObject obj = new JSONObject();
		obj.put("type", "T-shirt");
		obj.put("brand", "Polo");
		obj.put("design", "Round_neck");

		pd.setName("Full sleev T-shirt");
		pd.setPrice(500);
		pd.setProductType(ProductType.APPAREL.toString());
		//pd.setProductDetails(obj.toString().getBytes());
		pd.setProductDetails(obj.toString());
		productservice.insertProduct(pd);

		JSONObject obj1 = new JSONObject();
		obj1.put("type", "Trouser");
		obj1.put("brand", "Peter_England");
		obj1.put("design", "Plain");

		Product pd1 = new Product();
		pd1.setName("Black plain shirt");
		pd1.setPrice(700);
		pd1.setProductType(ProductType.APPAREL.toString());
		//pd1.setProductDetails(obj1.toString().getBytes());
		pd1.setProductDetails(obj1.toString());
		productservice.insertProduct(pd1);

		JSONObject obj2 = new JSONObject();
		obj2.put("type", "Kurthi");
		obj2.put("brand", "Soch");
		obj2.put("design", "Embroidered_kurthi");

		Product pd2 = new Product();
		pd2.setName("Straight kurthi");
		pd2.setPrice(800);
		pd2.setProductType(ProductType.APPAREL.toString());
	//	pd2.setProductDetails(obj2.toString().getBytes());
		pd2.setProductDetails(obj2.toString());
		productservice.insertProduct(pd2);

	}
	

	public void insertDefaultDataToUser() {
		User user = new User();
		user.setFirstName("Ram");
		user.setEmail("Ram@gmail.com");
		user.setLastName("chandar");
		user.setPassword("Chandra123");
		user.setPhoneNumber("8976234976");
		user.setAddress("Malleshwaram,Bangalore");
		user.setGender("Male");
		user.setCart(null);
		userService.insertUser(user);

		User user1 = new User();
		user1.setFirstName("Admin");
		user1.setEmail("Admin@gmail.com");
		user1.setLastName("Admin");
		user1.setPassword("Admin123");
		user1.setPhoneNumber("1234556765");
		user1.setAddress("Majestic,Bangalore");
		user1.setGender("Female");
		user1.setCart(null);
		userService.insertUser(user1);

		User user2 = new User();
		user2.setFirstName("Sita");
		user2.setEmail("Sita@gmail.com");
		user2.setLastName("Ram");
		user2.setPassword("Sita123");
		user2.setPhoneNumber("6754987612");
		user2.setAddress("Yeshwanthpur,Bangalore");
		user2.setGender("Female");
		user2.setCart(null);
		userService.insertUser(user2);

	}

}
