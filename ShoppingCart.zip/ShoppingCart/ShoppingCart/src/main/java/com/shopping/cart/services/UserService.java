package com.shopping.cart.services;

import java.util.Optional;

import com.shopping.cart.entity.User;

public interface UserService {
	
	public User validateUser(User user);
	
	public void insertUser(User user);
	
	public void updateUser(User user);

	public Optional<User> getById(int id);
	
	public void deleteUser(User user);
	

}
