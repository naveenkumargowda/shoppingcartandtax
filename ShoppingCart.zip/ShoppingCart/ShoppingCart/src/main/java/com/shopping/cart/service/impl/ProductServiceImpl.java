package com.shopping.cart.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shopping.cart.daos.ProductDao;
import com.shopping.cart.entity.Product;
import com.shopping.cart.services.ProductService;

@Service
@Transactional(propagation = Propagation.SUPPORTS,readOnly = true)
public class ProductServiceImpl implements ProductService {

	private static final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class.getSimpleName());
	
	@Autowired
	ProductDao productDao;

	@Override
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false)
	public void insertProduct(Product pd) {
		logger.info("Save product");
		productDao.save(pd);
	}

	@Override
	public List<Product> getAllProducts() {
		logger.info("Get all products");
		return productDao.findAll();
	}

	@Override
	public Optional<Product> getById(int id) {
		logger.info("Get product by Id");
		return productDao.findById(id);
	}

	@Override
	public List<Product> getByName(String name) {
		logger.info("Get product by name");
		return productDao.findByName(name);
	}

	@Override
	public List<Product> getByCategory(String category) {
		logger.info("Get product by category");
		return productDao.findByProductType(category);
	}

}
