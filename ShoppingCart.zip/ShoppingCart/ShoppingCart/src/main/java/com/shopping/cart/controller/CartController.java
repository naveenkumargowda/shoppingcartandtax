package com.shopping.cart.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.shopping.cart.entity.Cart;
import com.shopping.cart.entity.CartProduct;
import com.shopping.cart.entity.Product;
import com.shopping.cart.entity.User;
import com.shopping.cart.exception.ProductException;
import com.shopping.cart.services.CartProductService;
import com.shopping.cart.services.ProductService;
import com.shopping.cart.services.UserService;
import com.shopping.cart.utility.SearchCriteria;

@Controller
public class CartController {

	private static final Logger logger = LoggerFactory.getLogger(CartController.class.getSimpleName());
	@Autowired
	UserService userservice;

	@Autowired
	ProductService productService;

	@Autowired
	CartProductService cartProductservice;

	/* navigates to login page */
	@RequestMapping(value = "/")
	public ModelAndView login() {
		logger.info("Navigate to login page");
		ModelAndView mv = new ModelAndView();
		mv.setViewName("login");
		mv.addObject("user", new User());
		return mv;
	}

	/*
	 * validates username and password if valid moves to cart details page else
	 * gives error message in login page
	 */
	@RequestMapping(value = "/validate")
	public ModelAndView validateLogin(@ModelAttribute("user") User user) {
		logger.info("Validate user info");
		ModelAndView mv = new ModelAndView();
		User u = userservice.validateUser(user);
		if (null != u) {

			mv.addObject("user", u);

			mv.addObject("product", productService.getAllProducts());

			mv.setViewName("productspage");
		} else {
			mv.addObject("msg", "Invalid credentials");
			mv.addObject("user", new User());
			mv.setViewName("login");

		}
		return mv;
	}

	/* updates user ,insert records to cart and cart product tables */
	@RequestMapping(value = "/save")
	public ModelAndView saveCartDetails(@ModelAttribute("user") User user) {
		logger.info("updates user ,insert records to cart and cart product tables");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("product", productService.getAllProducts());
		try {

			Optional<User> optionalUser = userservice.getById(user.getId());
			User olduser = optionalUser.get();
			List<CartProduct> cp = new ArrayList<>();
			user.getCart().getCartProducts().forEach(cprod -> {
				if (cprod.getQuantity() > 0 && null != cprod.getProduct())
					cp.add(cprod);

			});
			user.getCart().setCartProducts(cp);
			olduser.setCart(user.getCart());
			userservice.insertUser(olduser);

			modelAndView.addObject("user", olduser);
			modelAndView.addObject("msg", "Successfully added to cart");

		} catch (Exception e) {
			logger.error("Error while saving data", e);
			modelAndView.addObject("msg", "Error while saving cart details");

		}
		modelAndView.setViewName("productspage");

		return modelAndView;
	}

	/* update and delete cart products */
	@RequestMapping(value = "/update")
	public ModelAndView updateCartDetails(@ModelAttribute("user") User user) {
		logger.info("update and delete cart products");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("product", productService.getAllProducts());
		try {
			Optional<User> optionalUser = userservice.getById(user.getId());
			User olduser = optionalUser.get();
			List<CartProduct> cartProducts = olduser.getCart().getCartProducts();
			cartProductservice.deletecartProducts(cartProducts);
			Cart cart = olduser.getCart();
			cart.setTotalPrice(user.getCart().getTotalPrice());
			List<CartProduct> cps = new ArrayList<>();
			user.getCart().getCartProducts().forEach(cp -> {
				cp.setCart(cart);
				if (cp.getQuantity() > 0) {
					cps.add(cp);
				}
			});

			cart.setCartProducts(cps);
			olduser.setCart(cart);
			userservice.updateUser(olduser);
			modelAndView.addObject("user", olduser);

			modelAndView.addObject("msg", "Successfully updated cart");
			modelAndView.setViewName("productspage");
		} catch (Exception e) {
			logger.error("Error while updating data", e);
			modelAndView.addObject("msg", "Error while updating cart details");

		}
		return modelAndView;
	}

	/* Delete user and its corresponding records in other tables */
	@RequestMapping(value = "/delete")
	public String deleteCartDetails(@ModelAttribute("user") User user) {
		logger.info("Delete user");
		try {
			userservice.deleteUser(user);
		} catch (Exception e) {
			logger.error("Error while deleting user");
			e.printStackTrace();
		}
		return "return:/";
	}

	@ResponseBody
	@RequestMapping(value = "/product")
	public List<Product> searchProduct(@RequestBody SearchCriteria search) {
		
		List<Product> pds=new ArrayList<>();
		if (search.getSearchType().equalsIgnoreCase("id")) {
			logger.info("Search product by Id");
			
			try {
				Optional<Product> opro = productService.getById(Integer.parseInt(search.getSearchValue()));
				pds.add(opro.get());
				System.out.println(pds.size());
			} catch (ProductException e) {
				logger.error("Error while fetching product by Id", e);
				e.printStackTrace();
			}
			
		}
		if (search.getSearchType().equalsIgnoreCase("category")) {

			logger.info("Search product by category");
			try {
				pds.addAll(productService.getByCategory(search.getSearchValue()));
			} catch (ProductException e) {
				System.out.println(e.getMessage());
				logger.error("Error while fetching product by category", e);
				e.printStackTrace();
			}
			
		}
		if (search.getSearchType().equalsIgnoreCase("name")) {

			logger.info("Search product by name");
			try {
				pds.addAll(productService.getByName(search.getSearchValue()));
			} catch (ProductException e) {
				logger.error("Error while fetching product by name", e);
				e.printStackTrace();
			}
			
		}
		return pds;
	}


}
