package com.shopping.cart.utility;

public enum ProductType {
	
	BOOK,APPAREL;
	
	
}
