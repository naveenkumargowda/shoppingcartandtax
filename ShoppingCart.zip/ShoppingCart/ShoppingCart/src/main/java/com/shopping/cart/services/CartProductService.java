package com.shopping.cart.services;

import java.util.List;

import com.shopping.cart.entity.CartProduct;

public interface CartProductService {
	
	public void insertcartProduct(CartProduct cd);
	
	public void updateinsertcartProduct(CartProduct cd);
	
	public void deletecartProduct(List<Integer> deleteCartProducts);

	public void deletecartProducts(List<CartProduct> cartProducts);
	
	

}
