package com.shopping.cart.utility;

import org.springframework.stereotype.Component;

@Component
public class SearchCriteria {
	private String searchType;
	private String searchValue;
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public String getSearchValue() {
		return searchValue;
	}
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	
	
	

}
