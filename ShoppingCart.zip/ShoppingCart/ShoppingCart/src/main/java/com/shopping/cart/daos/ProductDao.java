package com.shopping.cart.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.shopping.cart.entity.Product;

@Repository 
public interface ProductDao extends JpaRepository<Product,Integer> {
	
	@Query("select p from Product p where p.name=:name")
	public List<Product>  findByName(String name);
	
	
	@Query("select p from Product p where p.productType=:productType")
	public List<Product>  findByProductType(String productType);

}
