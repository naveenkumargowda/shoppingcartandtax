package com.shopping.cart.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shopping.cart.daos.UserDao;
import com.shopping.cart.entity.User;
import com.shopping.cart.services.UserService;

@Service
@Transactional(propagation = Propagation.SUPPORTS,readOnly = true)
public class UserServiceImpl implements UserService {
	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class.getSimpleName());

	@Autowired
	UserDao userdao;

	@Override
	public User validateUser(User user) {
		logger.info("Validate user info");
		List<User> lstUser=userdao.validateUser(user.getFirstName(), user.getPassword());
		if (lstUser.size()!=0)
			return lstUser.get(0);
		else
			return null;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false)
	public void insertUser(User user) {
		logger.info("Save user ");
		 userdao.save(user);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false)
	public void updateUser(User user) {
		logger.info("Update user");
		userdao.save(user);
		
	}

	@Override
	public Optional<User> getById(int id) {
		logger.info("Get user by Id");
		return userdao.findById(id);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false)
	public void deleteUser(User user) {
		logger.info("Delete user");
		userdao.delete(user);
		
	}
	
	

}
