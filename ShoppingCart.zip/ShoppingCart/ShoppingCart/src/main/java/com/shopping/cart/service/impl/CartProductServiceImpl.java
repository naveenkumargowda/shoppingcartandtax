package com.shopping.cart.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shopping.cart.daos.CartProductDao;
import com.shopping.cart.entity.CartProduct;
import com.shopping.cart.services.CartProductService;

@Service
@Transactional(propagation = Propagation.SUPPORTS,readOnly = true)
public class CartProductServiceImpl implements CartProductService {
	private static final Logger logger = LoggerFactory.getLogger(CartProductServiceImpl.class.getSimpleName());
	@Autowired
	CartProductDao cartProduct;

	@Override
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false)
	public void insertcartProduct(CartProduct cd) {
		logger.info("Saving cart product");
		cartProduct.save(cd);

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false)
	public void updateinsertcartProduct(CartProduct cd) {
		logger.info("Updating cart product");
		cartProduct.save(cd);

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false)
	public void deletecartProduct(List<Integer> deleteCartProducts) {
		logger.info("Deleting cart product");
		deleteCartProducts.stream().forEach(itm -> {
			cartProduct.deleteById(itm);
		});

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false)
	public void deletecartProducts(List<CartProduct> cartProducts) {
		logger.info("Deleting cart product");
		cartProducts.forEach(pro->{
			cartProduct.deleteById(pro.getId());
		});
		
	}

}
