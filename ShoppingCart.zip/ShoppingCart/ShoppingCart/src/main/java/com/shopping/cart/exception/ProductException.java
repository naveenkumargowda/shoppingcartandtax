package com.shopping.cart.exception;

public class ProductException extends RuntimeException{

	private static final long serialVersionUID = -470180507998010368L;
	
	ProductException()
	{
		super();
	}
	
	ProductException(String message)
	{
		super(message);
	}
	
	
}
